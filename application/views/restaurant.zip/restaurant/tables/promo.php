<div class="message">

</div>
<img height="100%" width="100%" src="<?php echo asset_url(); ?>images/adv_01.jpg"  />
