<div class="row">
<div class="col-xs-12 text-center">

  <h3><?php echo $warehouse_details['name']; ?></h3>

  <p>
  <?php echo $warehouse_details['address']; ?><br>
Tel: <?php echo $warehouse_details['phone']; ?> &nbsp;&nbsp; Email: <?php echo $warehouse_details['email']; ?> 
<br>
<br>

</p>
   </div><!--col-xs-12-->
</div><!--row-->