<a class="navbar-brand" >
	<img src="<?php echo asset_url(); ?>images/logo_pos.png" style="margin-left:50px; margin-top: -3px; width: 250px;">
</a>