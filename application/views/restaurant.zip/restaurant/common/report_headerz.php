<div class="row">
<div class="col-xs-12 text-center">

  <h3>Proceed Order</h3>

 <!-- <p>
  <?php  ?><br>
Tel: <?php /*echo $warehouse_details['phone']; ?> &nbsp;&nbsp; Email: <?php echo $warehouse_details['email'];*/ ?> 
<br>
<br>

</p>-->
   </div><!--col-xs-12-->
</div><!--row-->