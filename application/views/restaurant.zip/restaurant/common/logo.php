<a class="navbar-brand" href="<?php echo base_url('dashboard'); ?>">

	<img src="<?php echo asset_url(); ?>images/logo.png" style="margin-top: -15px; margin-left: -10px;

width: 60px;">

</a>