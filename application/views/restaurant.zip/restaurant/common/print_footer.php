<div class="row" style="font-size:12px;">
<p class="text-center">
<br />

Developed by: Sallelanka Solutions (pvt) Ltd.<br />
 Tel. +94777746654 WEB:www.sallelanka-solutions.com 
</p>
</div><!--row-->