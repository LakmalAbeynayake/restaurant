<?php  



		if(is_logged_in()){


		}else {

			redirect(base_url(),'refresh');

			exit();

		}

//print_r($this->session->all_userdata()); 


//$this->load->view("common/random");





$Common_Model = new Common_Model();

$usr_permtn_pubvr = $Common_Model->is_avalable_for_use_this_link_for_user($this->session->userdata('ss_group_id'),'users');

	//echo "<pre>";

//echo print_r($usr_permtn_pubvr);	





function random_str($length, $keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')

{

    $str = '';

   // $max = mb_strlen($keyspace, '8bit') - 1;

   // for ($i = 0; $i < $length; ++$i) {

    //    $str .= $keyspace[random_int(0, $max)];

   // }

    return rand(10,100);

}

				

?>
<style>
.dataTables_processing {
	position: absolute;
	top: 50%;
	left: 50%;
	width: 100%;
	height: 40px;
	margin-left: -50%;
	margin-top: -25px;
	padding-top: 20px;
	text-align: center;
	font-size: 1.2em;
	background-color: white;
	background: -webkit-gradient(linear, left top, right top, color-stop(0%, rgba(255,255,255,0)), color-stop(25%, rgba(255,255,255,0.9)), color-stop(75%, rgba(255,255,255,0.9)), color-stop(100%, rgba(255,255,255,0)));
	background: -webkit-linear-gradient(left, rgba(255,255,255,0) 0%, rgba(255,255,255,0.9) 25%, rgba(255,255,255,0.9) 75%, rgba(255,255,255,0) 100%);
	background: -moz-linear-gradient(left, rgba(255,255,255,0) 0%, rgba(255,255,255,0.9) 25%, rgba(255,255,255,0.9) 75%, rgba(255,255,255,0) 100%);
	background: -ms-linear-gradient(left, rgba(255,255,255,0) 0%, rgba(255,255,255,0.9) 25%, rgba(255,255,255,0.9) 75%, rgba(255,255,255,0) 100%);
	background: -o-linear-gradient(left, rgba(255,255,255,0) 0%, rgba(255,255,255,0.9) 25%, rgba(255,255,255,0.9) 75%, rgba(255,255,255,0) 100%);
	background: linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(255,255,255,0.9) 25%, rgba(255,255,255,0.9) 75%, rgba(255,255,255,0) 100%);
}
</style>

<div class="main-navigation navbar-collapse collapse"> 
  
  <!-- start: MAIN MENU TOGGLER BUTTON -->
  
  <div class="navigation-toggler"> <i class="clip-chevron-left"></i> <i class="clip-chevron-right"></i> </div>
  
  <!-- end: MAIN MENU TOGGLER BUTTON --> 
  
  <!-- start: MAIN NAVIGATION MENU -->
  
  <ul class="main-navigation-menu">
    <li <?php if($main_menu_name=='dashboard') {echo 'class="active open"';} ?>> <a href="<?php echo base_url('pos'); ?>"><i class="fa fa-th-large"></i> <span class="title"> POS Screen </span><span class="selected"></span> </a></li>
    <li <?php if($main_menu_name=='dashboard') {echo 'class="active open"';} ?>> <a href="<?php echo base_url('restaurant/view/tables'); ?>"><i class="fa fa-th-large"></i> <span class="title"> Tables </span><span class="selected"></span> </a></li>
    
    
    
    <li <?php if($main_menu_name=='kitchen') {echo 'class="active open collapse"';} ?>> <a href="javascript:void(0)"><i class="fa fa-barcode"></i> <span class="title"> Products </span><i class="icon-arrow"></i> <span class="selected"></span> </a>
      <ul class="sub-menu">
        <?php 

							//if($usr_permtn_pubvr['usrgp_permission_view'])

							{

							?>
        <li <?php if($sub_menu_name=='products') {echo 'class="active open"';} ?>> <a href="<?php echo base_url('products'); ?>"> <span class="title"> List Products</span></a></li>
        <?php }?>
        <?php if ($this->session->userdata('ss_group_id')<3){ ?>
        <li <?php if($sub_menu_name=='add_products') {echo 'class="active open"';} ?>> <a href="<?php echo base_url('products/add'); ?>"> <span class="title"> Add Products</span></a></li>
        <?php }?>
      </ul>
    </li>
    <li <?php if($main_menu_name=='sales') {echo 'class="active open"';} ?>> <a href="javascript:void(0)"><i class="fa fa-heart"></i> <span class="title"> Sales </span><i class="icon-arrow"></i> <span class="selected"></span> </a>
      <ul class="sub-menu">
        <li <?php if($sub_menu_name=='sales') {echo 'class="active open"';} ?>> <a href="<?php echo base_url('sales'); ?>"> <span class="title"> List Sales</span></a></li>
        <li <?php if($sub_menu_name=='add_sales') {echo 'class="active open"';} ?>> <a href="<?php echo base_url('sales/add/'.random_str(6).(mt_rand())); ?>"> <span class="title"> Add Sales</span></a></li>
        <li <?php if($sub_menu_name=='sales_return') {echo 'class="active open"';} ?>> <a href="<?php echo base_url('sales/sales_return'); ?>"> <span class="title"> List Return Sales</span></a></li>
      </ul>
    </li>
    <li <?php if($main_menu_name=='order') {echo 'class="active open"';} ?>> <a href="javascript:void(0)"><i class="fa fa-inbox"></i> <span class="title"> Orders </span><i class="icon-arrow"></i> <span class="selected"></span></a>
      <ul class="sub-menu">
        <li <?php if($sub_menu_name=='order') {echo 'class="active open"';} ?>> <a href="<?php echo base_url('order/order_list'); ?>"> <span class="title"> List Order</span></a></li>
        <li <?php if($sub_menu_name=='add_order') {echo 'class="active open"';} ?>> <a href="<?php echo base_url('order/add_order'); ?>"> <span class="title"> Add Order</span></a></li>
        <li <?php if($sub_menu_name=='pending_order') {echo 'class="active open"';} ?>> <a href="<?php echo base_url('order/pending_order_list'); ?>"> <span class="title">Pending Order</span></a></li>
        
        <!-- <li <?php if($sub_menu_name=='sales_return') {echo 'class="active open"';} ?>>

									<a href="<?php echo base_url('sales/sales_return'); ?>">

                                    <span class="title"> List Return Sales</span></a></li>-->
        
      </ul>
    </li>
    <li <?php if($main_menu_name=='proceed_order') {echo 'class="active open"';} ?>> <a href="javascript:void(0)"><i class="fa fa-heart"></i> <span class="title"> Production </span><i class="icon-arrow"></i> <span class="selected"></span></a>
      <ul class="sub-menu">
        <li <?php if($sub_menu_name=='proceed_order') {echo 'class="active open"';} ?>> <a href="<?php echo base_url('proceed_order/proceed_order_list'); ?>"> <span class="title">Finished Goods</span></a></li>
        
        <!--<li <?php if($sub_menu_name=='add_order') {echo 'class="active open"';} ?>>

<a href="<?php echo base_url('order/add_order'); ?>">

<span class="title"> Add Order</span></a></li>--> 
        
        <!--<li <?php if($sub_menu_name=='pending_order') {echo 'class="active open"';} ?>>

<a href="<?php echo base_url('proceed_order/pending_order_list'); ?>">

<span class="title">Proceed Order</span></a></li>-->
        
      </ul>
    </li>
    <?php if ($this->session->userdata('ss_group_id')<3){}?>
    <?php if ($this->session->userdata('ss_group_id')<3){}?>
    <?php if ($this->session->userdata('ss_group_id')<3){}?>
  </ul>
  
  <!-- end: MAIN NAVIGATION MENU --> 
  
</div>
